package Metodos;
import java.sql.SQLException;

import Metodos.MetodAccess;
public class PruebaConexion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MetodAccess con = new MetodAccess();
		
		try {
			System.out.print("Tu base de datos ha sido ");
			con.Conectar();
		}catch(SQLException e){
			e.printStackTrace();
	    }
		
	}

}
