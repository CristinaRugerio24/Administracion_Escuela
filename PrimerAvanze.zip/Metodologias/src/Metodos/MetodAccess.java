package Metodos;
import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;

public class MetodAccess {
	public Statement stmt = null;
    public Connection conn = null;
    public ResultSet rs;
    
    public MetodAccess(){
    	
    }
  
  //Funcion para conectarnos a nuestra base de datos 
    public void Conectar() throws SQLException{
          OracleDataSource ods = new OracleDataSource();
          String url = "jdbc:oracle:thin:Direccion/Direccion@//localhost:1521/xe";
          ods.setURL(url);
          conn = ods.getConnection();
          stmt = conn.createStatement();
          System.out.println("CONECTADA");
    }
    
    public void insertarMaestro(String NoTrabajador,String Nombre,String NSS,String Fecha_Nac, String  Curp, String Direccion, String Edad,String C_Institucional,String No_Telefono,String Edo_Civil, String Grado_Estudio, String Tiene_hijos, String Nom_C, String Dir_C, String Num1, String Num2, String NombreNivel) throws SQLException{
    	int tupla = stmt.executeUpdate("insert into MAESTRO values('"+NoTrabajador+"','"+Nombre+"','"+NSS+"','"+Fecha_Nac+"','"+Curp+"','"+Direccion+"','"+Edad+"','"+C_Institucional+"','"+No_Telefono+"','"+Edo_Civil+"','"+Grado_Estudio+"','"+Tiene_hijos+"','"+Nom_C+"','"+Dir_C+"','"+Num1+"','"+Num2+"','"+NombreNivel+"')");
        if(tupla==1){
        	System.out.println ("Maestro Agregado");
        }
    }
    
    public void insertarMateria(String ID,String Nombre,String Grado,String NoTrabajador, String NombreNivel) throws SQLException{
    	int tupla = stmt.executeUpdate("insert into MATERIA values('"+ID+"','"+Nombre+"','"+Grado+"','"+NoTrabajador+"','"+NombreNivel+"')");
        if(tupla==1){
        	System.out.println ("Materia Agregada");
        }
    }
    
    public void insertarTaller(String ID,String NombreT,String NoTrabajador, String NombreNivel) throws SQLException{
    	int tupla = stmt.executeUpdate("insert into TALLER values('"+ID+"','"+NombreT+"','"+NoTrabajador+"','"+NombreNivel+"')");
        if(tupla==1){
        	System.out.println ("Taller Agregado");
        }
    }
    
}
    
