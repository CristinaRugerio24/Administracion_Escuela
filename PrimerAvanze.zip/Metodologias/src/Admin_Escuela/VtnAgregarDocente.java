package Admin_Escuela;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import Metodos.MetodAccess;
import java.sql.SQLException;
import java.util.Random;
public class VtnAgregarDocente {

	private JFrame frame;
	private JTextField txtNombre;
	private JTextField txtApellidoP;
	private JTextField txtApellidoM;
	private JTextField txtEdad;
	private JTextField txtDia;
	private JTextField txtCurp;
	private JTextField txtDireccion;
	private JTextField txtNumTel;
	private JTextField txtCorreoI;
	private JTextField txtNombreC;
	private JTextField txtDireccionC;
	private JTextField txtNumC1;
	public Random numAleatorio = new Random();
	public int NoTrabaj = 100000 + numAleatorio.nextInt(900000);
	public int idMateria = 100 + numAleatorio.nextInt(900);
	public int idTaller = 100 + numAleatorio.nextInt(900);
	public int idNSS1 = 10000 + numAleatorio.nextInt(90000);
	public int idNSS2 = 100000 + numAleatorio.nextInt(900000);
	JComboBox comboArea;
	JComboBox comboMateria;
	JComboBox estadoGradoE;
	JRadioButton rdbtnSi;
	JRadioButton rdbtnNo;
	JRadioButton rdbtnMateria;
	JRadioButton rdbtnTaller;
	private JTextField txtNumC2;
	public JComboBox comboArea_Taller = new JComboBox();
	public JComboBox comboTaller = new JComboBox();
	private JTextField textMes;
	private JTextField textAno;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VtnAgregarDocente window = new VtnAgregarDocente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public VtnAgregarDocente() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("colegio.png"));
		frame.setFont(new Font("Apple Garamond", Font.BOLD, 22));
		frame.setForeground(Color.WHITE);
		frame.getContentPane().setFont(new Font("Leelawadee UI", Font.PLAIN, 12));
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setTitle("Agregar Docente");
		frame.setBounds(0, 0, 842, 628);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre Completo");
		lblNombre.setForeground(new Color(102, 153, 255));
		lblNombre.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNombre.setBounds(45, 70, 172, 25);
		frame.getContentPane().add(lblNombre);
		
		JLabel lblEdad = new JLabel("Edad");
		lblEdad.setForeground(new Color(102, 153, 255));
		lblEdad.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblEdad.setBounds(45, 143, 137, 25);
		frame.getContentPane().add(lblEdad);
		
		JLabel lblFechaNac = new JLabel("Fecha de Nacimiento");
		lblFechaNac.setForeground(new Color(102, 153, 255));
		lblFechaNac.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblFechaNac.setBounds(553, 70, 203, 25);
		frame.getContentPane().add(lblFechaNac);
		
		JLabel lblCurp = new JLabel("CURP");
		lblCurp.setForeground(new Color(102, 153, 255));
		lblCurp.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblCurp.setBounds(215, 143, 137, 25);
		frame.getContentPane().add(lblCurp);
		
		JLabel lblGradoE = new JLabel("Grado de Estudios");
		lblGradoE.setForeground(new Color(102, 153, 255));
		lblGradoE.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblGradoE.setBounds(455, 143, 179, 25);
		frame.getContentPane().add(lblGradoE);
		
		JLabel lblDireccion = new JLabel("Direcci\u00F3n ");
		lblDireccion.setForeground(new Color(102, 153, 255));
		lblDireccion.setHorizontalAlignment(SwingConstants.LEFT);
		lblDireccion.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblDireccion.setBounds(591, 222, 102, 25);
		frame.getContentPane().add(lblDireccion);
		
		JLabel lblNumTel = new JLabel("N\u00FAmero de Tel\u00E9fono");
		lblNumTel.setForeground(new Color(102, 153, 255));
		lblNumTel.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNumTel.setBounds(215, 222, 187, 25);
		frame.getContentPane().add(lblNumTel);
		
		JLabel lblCorreoI = new JLabel("Correo Institucional");
		lblCorreoI.setForeground(new Color(102, 153, 255));
		lblCorreoI.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblCorreoI.setBounds(234, 292, 187, 25);
		frame.getContentPane().add(lblCorreoI);
		
		comboArea = new JComboBox();
		comboArea.setToolTipText("");
		comboArea.setModel(new DefaultComboBoxModel(new String[] {"Seleccione","Maternal", "Preescolar", "Primaria", "Secundaria"}));
		comboArea.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		comboArea.setBounds(30, 399, 126, 25);
		frame.getContentPane().add(comboArea);
		
		comboMateria = new JComboBox();
		comboMateria.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		comboMateria.setBounds(181, 399, 203, 25);
		frame.getContentPane().add(comboMateria);
		
		
		txtNombre = new JTextField();
		txtNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				//Validar solo letras
				if(!Character.isLetter(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		txtNombre.setFont(new Font("Arial", Font.PLAIN, 14));
		txtNombre.setBounds(45, 97, 172, 25);
		frame.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtApellidoP = new JTextField();
		txtApellidoP.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				//Validar solo letras
				if(!Character.isLetter(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		txtApellidoP.setFont(new Font("Arial", Font.PLAIN, 14));
		txtApellidoP.setColumns(10);
		txtApellidoP.setBounds(232, 97, 143, 25);
		frame.getContentPane().add(txtApellidoP);
		
		txtApellidoM = new JTextField();
		txtApellidoM.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				//Validar solo letras
				if(!Character.isLetter(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		txtApellidoM.setFont(new Font("Arial", Font.PLAIN, 14));
		txtApellidoM.setColumns(10);
		txtApellidoM.setBounds(385, 97, 143, 25);
		frame.getContentPane().add(txtApellidoM);
		
		JLabel lblError = new JLabel("");
		lblError.setForeground(Color.RED);
		lblError.setFont(new Font("Apple Garamond", Font.PLAIN, 16));
		lblError.setBounds(334, 145, 137, 25);
		frame.getContentPane().add(lblError);
				
		txtEdad = new JTextField();
		txtEdad.addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 2;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = txtEdad.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		txtEdad.setFont(new Font("Arial", Font.PLAIN, 14));
		txtEdad.setColumns(10);
		txtEdad.setBounds(45, 170, 143, 25);
		frame.getContentPane().add(txtEdad);
		
		txtDia = new JTextField();
        txtDia.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 2;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = txtDia.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		txtDia.setFont(new Font("Arial", Font.PLAIN, 14));
		txtDia.setForeground(Color.BLACK);
		txtDia.setColumns(10);
		txtDia.setBounds(554, 97, 46, 25);
		frame.getContentPane().add(txtDia);
		
		textMes = new JTextField();
        textMes.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 2;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = textMes.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		textMes.setForeground(Color.BLACK);
		textMes.setFont(new Font("Arial", Font.PLAIN, 14));
		textMes.setColumns(10);
		textMes.setBounds(615, 97, 46, 25);
		frame.getContentPane().add(textMes);
		
		textAno = new JTextField();
        textAno.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 4;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = textAno.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		textAno.setForeground(Color.BLACK);
		textAno.setFont(new Font("Arial", Font.PLAIN, 14));
		textAno.setColumns(10);
		textAno.setBounds(673, 97, 46, 25);
		frame.getContentPane().add(textAno);
		
		txtCurp = new JTextField();
		txtCurp.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				//Delimitar CURP
				int limite = 18;
				int tam = txtCurp.getText().length();
				if(tam == limite) {
					e.consume();
				}
			}
		});
		txtCurp.setFont(new Font("Arial", Font.PLAIN, 14));
		txtCurp.setColumns(10);
		txtCurp.setBounds(215, 169, 206, 25);
		frame.getContentPane().add(txtCurp);
		
		txtDireccion = new JTextField();
		txtDireccion.setFont(new Font("Arial", Font.PLAIN, 14));
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(580, 247, 206, 25);
		frame.getContentPane().add(txtDireccion);
		
		txtNumTel = new JTextField();
		txtNumTel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 10;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = txtNumTel.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		txtNumTel.setFont(new Font("Arial", Font.PLAIN, 14));
		txtNumTel.setColumns(10);
		txtNumTel.setBounds(215, 246, 187, 25);
		frame.getContentPane().add(txtNumTel);
		
		txtCorreoI = new JTextField();
		txtCorreoI.setFont(new Font("Arial", Font.PLAIN, 14));
		txtCorreoI.setColumns(10);
		txtCorreoI.setBounds(225, 324, 226, 25);
		frame.getContentPane().add(txtCorreoI);
		
		JLabel lblIconoC = new JLabel("");
		lblIconoC.setBounds(729, 97, 27, 25);
        ImageIcon icon5 = new ImageIcon("C:\\\\Users\\\\Sam Hernandez\\\\Downloads\\\\VentanaInsertar\\\\VentanaInsertar\\\\Calendario.png");
        Icon iconx = new ImageIcon(icon5.getImage().getScaledInstance(lblIconoC.getWidth(), lblIconoC.getHeight(), Image.SCALE_DEFAULT));
        lblIconoC.setText(null);
        lblIconoC.setIcon(iconx);
		frame.getContentPane().add(lblIconoC);
		
		JLabel lblNvelEducativo = new JLabel("N\u00EDvel Educativo");
		lblNvelEducativo.setForeground(new Color(102, 153, 255));
		lblNvelEducativo.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNvelEducativo.setBounds(28, 377, 143, 25);
		frame.getContentPane().add(lblNvelEducativo);
		
		JLabel lblMaterias = new JLabel("Materia");
		lblMaterias.setForeground(new Color(102, 153, 255));
		lblMaterias.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblMaterias.setBounds(244, 377, 85, 25);
		frame.getContentPane().add(lblMaterias);
		
		JComboBox estadoCivil = new JComboBox();
		estadoCivil.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		estadoCivil.setModel(new DefaultComboBoxModel(new String[] {"Seleccione","Soltero", "Casado", "Divorciado", "Viudo", "Union Libre"}));
		estadoCivil.setBounds(437, 245, 102, 25);
		frame.getContentPane().add(estadoCivil);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Seleccione","Licenciatura", "Maestria/Posgrado", "Doctorado"}));
		comboBox.setBounds(455, 169, 238, 25);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel = new JLabel("Estado c\u00EDvil");
		lblNewLabel.setForeground(new Color(102, 153, 255));
		lblNewLabel.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNewLabel.setBounds(437, 225, 117, 18);
		frame.getContentPane().add(lblNewLabel);
		
		MetodAccess metodosBD = new MetodAccess();
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.setBackground(Color.WHITE);
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nombreCompleto,curp, direccion,edad,correoIns,numTelefono,nombrEmergencia,dirEmergencia,numE1,numE2,escolaridad_maestro,edo_civil, nivel_Edu;
				String nombreMateria, nombreGrado,nombreTaller;
				NoTrabaj = 100000 + numAleatorio.nextInt(900000);
				idMateria = 100 + numAleatorio.nextInt(900);
				idTaller = 100 + numAleatorio.nextInt(900);
				idNSS1 = 10000 + numAleatorio.nextInt(90000);
				idNSS2 = 100000 + numAleatorio.nextInt(900000);
				String No_Trabajador = Integer.toString(NoTrabaj); //variable para BD NUMERO DE TRABAJADOR
				String id_Materia = Integer.toString(idMateria);
				String id_Taller = Integer.toString(idTaller);
				String id_idNSS1 = Integer.toString(idNSS1);
				String id_idNSS2 = Integer.toString(idNSS2);
				//Se concateno para generar NSS DE 11 DIGITOS
			    String NSS = id_idNSS1 + id_idNSS2;
				try {
					metodosBD.Conectar();
					int cont=0;
					escolaridad_maestro = (String) comboBox.getSelectedItem(); //variable para BD GRADO_ESTUDIOS
					edo_civil = (String) estadoCivil.getSelectedItem(); //variable para BD ESTADO CIVIL
					
					String numCadena1 = txtDia.getText(); 
		        	int numDia = Integer.parseInt(numCadena1);
		        	String numCadena = textMes.getText(); 
		        	int numMes = Integer.parseInt(numCadena);
					
					// Patron para validar el email
			        Pattern pattern = Pattern
			                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
			        // El email a validar
			        String email = txtCorreoI.getText();
			        Matcher mather = pattern.matcher(email);
			        if(cont==0) {
			        	 if (txtNombre.getText().isEmpty() || txtApellidoP.getText().isEmpty() || txtApellidoM.getText().isEmpty() || txtDia.getText().isEmpty() || textMes.getText().isEmpty() || textAno.getText().isEmpty() || txtEdad.getText().isEmpty() || txtCurp.getText().isEmpty() || txtNumTel.getText().isEmpty()
							|| txtDireccion.getText().isEmpty() || txtCorreoI.getText().isEmpty() || txtNombreC.getText().isEmpty() || txtDireccionC.getText().isEmpty() || txtNumC1.getText().isEmpty() || txtNumC2.getText().isEmpty()){
						      JOptionPane.showMessageDialog(null, "No has llenado todos los campos", " Error!", JOptionPane.ERROR_MESSAGE);
						      cont=1;
					      }else if (rdbtnSi.isSelected()==false && rdbtnNo.isSelected()==false){
						     JOptionPane.showMessageDialog(null, "No has seleccionado una opcion", "�Error!", JOptionPane.ERROR_MESSAGE);
						     cont=1;
					      }else if(rdbtnMateria.isSelected()==false && rdbtnTaller.isSelected()==false) {
					    	  JOptionPane.showMessageDialog(null, "No has seleccionado la asignatura o taller a impartir", "�Error!", JOptionPane.ERROR_MESSAGE);
							     cont=1;
					      }else if (mather.find() == false) {
						     JOptionPane.showMessageDialog(null, "Correo electronico invalido", " �Error!", JOptionPane.ERROR_MESSAGE);
						     cont=1;
					      }else if(escolaridad_maestro.equals("Seleccione")){
					    	  comboBox.setSelectedItem(escolaridad_maestro);
					    	  cont=1;
					      }else if(edo_civil.equals("Seleccione")){
					    	  estadoCivil.setSelectedItem(edo_civil);
					    	  cont=1;
					      }else if(numMes > 12){
					    	  JOptionPane.showMessageDialog(null, "Mes incorecto,teclealo de nuevo", "�Error!", JOptionPane.ERROR_MESSAGE);
							  cont=1;
					      }else if(numDia > 31){
					    	  JOptionPane.showMessageDialog(null, "Dia incorecto,teclealo de nuevo", "�Error!", JOptionPane.ERROR_MESSAGE);
							  cont=1;
					      }
			        }//if del contador
			       
			        if(cont==0){
			        	String tiene_hijos;
			        	String numCadDia= txtDia.getText();
			        	String numCadMes= textMes.getText();
			        	String numCadAno= textAno.getText();
			        	String numCadFecha= numCadDia + "/" + numCadMes + "/" + numCadAno;
			        	nombreCompleto = txtNombre.getText()+ " "+ txtApellidoP.getText()+" "+txtApellidoM.getText();
			        	curp = txtCurp.getText();
			        	direccion = txtDireccion.getText();
			        	edad = txtEdad.getText();
			        	correoIns = txtCorreoI.getText();
			        	numTelefono =txtNumTel.getText();
			        	nombrEmergencia = txtNombreC.getText();
			        	dirEmergencia = txtDireccionC.getText();
			        	numE1 = txtNumC1.getText();
			        	numE2 = txtNumC2.getText();
			        	System.out.println("Se agrego la tupla a la DB");
			        	JOptionPane.showMessageDialog(null, "�Docente agregado correctamente!");
			        	//nombre del nivel
			        	if(rdbtnMateria.isSelected()==true){
			        		System.out.println("Eligio una materia");
			        		nivel_Edu = (String) comboArea.getSelectedItem(); //variable para BD NIVEL EDUCATIVO  
			        		nombreMateria= (String) comboMateria.getSelectedItem();
			        		nombreGrado= (String) estadoGradoE.getSelectedItem();
			        		if(rdbtnSi.isSelected()==true){
				        		tiene_hijos="Si";  
				        		metodosBD.insertarMaestro(No_Trabajador,nombreCompleto,NSS,numCadFecha,curp,direccion,edad,correoIns,numTelefono,edo_civil,escolaridad_maestro,tiene_hijos,nombrEmergencia,dirEmergencia,numE1,numE2,nivel_Edu);
			        		}
				        	if(rdbtnNo.isSelected()==true){
				        		tiene_hijos="No";;   
				        		metodosBD.insertarMaestro(No_Trabajador,nombreCompleto,NSS,numCadFecha,curp,direccion,edad,correoIns,numTelefono,edo_civil,escolaridad_maestro,tiene_hijos,nombrEmergencia,dirEmergencia,numE1,numE2,nivel_Edu);
				        	}
				        	metodosBD.insertarMateria(id_Materia,nombreMateria,nombreGrado,No_Trabajador,nivel_Edu);
			        	}
			        	
			        	if(rdbtnTaller.isSelected()==true){
			        		System.out.println("Eligio un taller");
			        		nivel_Edu = (String) comboArea_Taller.getSelectedItem(); //variable para BD NIVEL EDUCATIVO  
			        		nombreTaller= (String) comboTaller.getSelectedItem();
			        		if(rdbtnSi.isSelected()==true){
			        			tiene_hijos="Si";   
				        		metodosBD.insertarMaestro(No_Trabajador,nombreCompleto,NSS,numCadFecha,curp,direccion,edad,correoIns,numTelefono,edo_civil,escolaridad_maestro,tiene_hijos,nombrEmergencia,dirEmergencia,numE1,numE2,nivel_Edu);
				        	}
				        	if(rdbtnNo.isSelected()==true){
				        		tiene_hijos="No";;   
				        		metodosBD.insertarMaestro(No_Trabajador,nombreCompleto,NSS,numCadFecha,curp,direccion,edad,correoIns,numTelefono,edo_civil,escolaridad_maestro,tiene_hijos,nombrEmergencia,dirEmergencia,numE1,numE2,nivel_Edu);
				        	}
				        	metodosBD.insertarTaller(id_Taller,nombreTaller, No_Trabajador,nivel_Edu);
			        	}
				    	
			           }else {
			        	   System.out.println("No se agrego la tupla a la DB");
			        }
				}catch(SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		btnGuardar.setFont(new Font("Apple Garamond", Font.BOLD, 20));
		btnGuardar.setBounds(657, 503, 62, 61);
		btnGuardar.setBorder(null);
        ImageIcon icon2 = new ImageIcon("C:\\\\Users\\\\Sam Hernandez\\\\Downloads\\\\VentanaInsertar\\\\VentanaInsertar\\\\guardar.png");
        Icon icono2 = new ImageIcon(icon2.getImage().getScaledInstance(btnGuardar.getWidth(), btnGuardar.getHeight(), Image.SCALE_DEFAULT));
        btnGuardar.setText(null);	
        btnGuardar.setIcon(icono2);
		frame.getContentPane().add(btnGuardar);
		
		comboArea_Taller.setToolTipText("");
		comboArea_Taller.setModel(new DefaultComboBoxModel(new String[] {"Seleccione","Maternal", "Preescolar", "Primaria"}));
		comboArea_Taller.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		comboArea_Taller.setBounds(30, 528, 126, 25);
		frame.getContentPane().add(comboArea_Taller);
		
		JLabel lblTallerName = new JLabel("Taller");
		lblTallerName.setForeground(new Color(102, 153, 255));
		lblTallerName.setFont(new Font("Dialog", Font.BOLD, 18));
		lblTallerName.setBounds(267, 503, 62, 25);
		frame.getContentPane().add(lblTallerName);
		
		comboTaller.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		comboTaller.setBounds(199, 528, 203, 25);
		frame.getContentPane().add(comboTaller);
		
		ButtonGroup grupo1 = new ButtonGroup();
		
		rdbtnSi = new JRadioButton("Si");
		rdbtnSi.setBackground(Color.WHITE);
		rdbtnSi.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		rdbtnSi.setBounds(55, 246, 53, 23);
		frame.getContentPane().add(rdbtnSi);
		
		JLabel lbltieneHijos = new JLabel("\u00BFTiene hijos?");
		lbltieneHijos.setForeground(new Color(102, 153, 255));
		lbltieneHijos.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lbltieneHijos.setBounds(45, 222, 126, 25);
		frame.getContentPane().add(lbltieneHijos);
		
		rdbtnNo = new JRadioButton("No");
		rdbtnNo.setBackground(Color.WHITE);
		rdbtnNo.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		rdbtnNo.setBounds(110, 246, 62, 23);
		frame.getContentPane().add(rdbtnNo);
		
		grupo1.add(rdbtnSi);
		grupo1.add(rdbtnNo);
		
		ButtonGroup grupo2 = new ButtonGroup();
		
		rdbtnMateria = new JRadioButton("Materia");
		rdbtnMateria.setFont(new Font("Dialog", Font.PLAIN, 18));
		rdbtnMateria.setBackground(Color.WHITE);
		rdbtnMateria.setBounds(45, 323, 91, 23);
		frame.getContentPane().add(rdbtnMateria);
		
		rdbtnTaller = new JRadioButton("Taller");
		rdbtnTaller.setFont(new Font("Dialog", Font.PLAIN, 18));
		rdbtnTaller.setBackground(Color.WHITE);
		rdbtnTaller.setBounds(138, 323, 79, 23);
		frame.getContentPane().add(rdbtnTaller);
		
		grupo2.add(rdbtnMateria);
		grupo2.add(rdbtnTaller);
		
		rdbtnMateria.addActionListener(new OyenteBtnMateria());
		rdbtnTaller.addActionListener(new OyenteBtnTaller());
		
		JLabel lblContactoDeEmergencia = new JLabel("CONTACTO DE EMERGENCIA");
		lblContactoDeEmergencia.setForeground(new Color(51, 102, 204));
		lblContactoDeEmergencia.setFont(new Font("Just Mandrawn", Font.PLAIN, 20));
		lblContactoDeEmergencia.setBounds(481, 324, 283, 25);
		frame.getContentPane().add(lblContactoDeEmergencia);
		
		txtNombreC = new JTextField();
		txtNombreC.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				//Validar solo letras
				if(!Character.isLetter(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		txtNombreC.setFont(new Font("Arial", Font.PLAIN, 14));
		txtNombreC.setColumns(10);
		txtNombreC.setBounds(408, 401, 187, 25);
		frame.getContentPane().add(txtNombreC);
		
		JLabel lblNombre_1 = new JLabel("Nombre");
		lblNombre_1.setForeground(new Color(102, 153, 255));
		lblNombre_1.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNombre_1.setBounds(419, 377, 93, 25);
		frame.getContentPane().add(lblNombre_1);
		
		JLabel lblDireccin = new JLabel("Direcci\u00F3n");
		lblDireccin.setForeground(new Color(102, 153, 255));
		lblDireccin.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblDireccin.setBounds(408, 436, 137, 25);
		frame.getContentPane().add(lblDireccin);
		
		txtDireccionC = new JTextField();
		txtDireccionC.setFont(new Font("Arial", Font.PLAIN, 14));
		txtDireccionC.setColumns(10);
		txtDireccionC.setBounds(408, 466, 213, 25);
		frame.getContentPane().add(txtDireccionC);
		
		JLabel lblNombre_1_1 = new JLabel("Num/Contacto 1");
		lblNombre_1_1.setForeground(new Color(102, 153, 255));
		lblNombre_1_1.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNombre_1_1.setBounds(645, 377, 151, 25);
		frame.getContentPane().add(lblNombre_1_1);
		
		txtNumC1 = new JTextField();
		txtNumC1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 10;
				//Validar solo numeros y tama�o de 10
				char car = e.getKeyChar();
				int tam = txtNumC1.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		txtNumC1.setFont(new Font("Arial", Font.PLAIN, 14));
		txtNumC1.setColumns(10);
		txtNumC1.setBounds(655, 401, 126, 25);
		frame.getContentPane().add(txtNumC1);
		
		JLabel lblNewLabel_1 = new JLabel("Grado");
		lblNewLabel_1.setForeground(new Color(102, 153, 255));
		lblNewLabel_1.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNewLabel_1.setBounds(40, 443, 79, 18);
		frame.getContentPane().add(lblNewLabel_1);
		
		estadoGradoE = new JComboBox();
		estadoGradoE.setFont(new Font("Apple Garamond", Font.PLAIN, 18));
		estadoGradoE.setBounds(110, 440, 117, 25);
		frame.getContentPane().add(estadoGradoE);
		
		JLabel lblNewLabel_2 = new JLabel("DATOS PERSONALES DOCENTES");
		lblNewLabel_2.setForeground(new Color(51, 102, 255));
		lblNewLabel_2.setFont(new Font("Just Mandrawn", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(45, 22, 512, 40);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNombre_1_1_1 = new JLabel("Num/Contacto 2");
		lblNombre_1_1_1.setForeground(new Color(102, 153, 255));
		lblNombre_1_1_1.setFont(new Font("Apple Garamond", Font.BOLD, 18));
		lblNombre_1_1_1.setBounds(645, 436, 162, 25);
		frame.getContentPane().add(lblNombre_1_1_1);
		
		txtNumC2 = new JTextField();
		txtNumC2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				int limite  = 10;
				//Validar solo numeros y tama�o de 2
				char car = e.getKeyChar();
				int tam = txtNumC2.getText().length();
				if(tam == limite) {
					e.consume();
				}else if((car<'0' || car>'9')) {
					e.consume();
				}
			}
		});
		txtNumC2.setFont(new Font("Arial", Font.PLAIN, 14));
		txtNumC2.setColumns(10);
		txtNumC2.setBounds(660, 466, 126, 25);
		frame.getContentPane().add(txtNumC2);
		
		JLabel lblImg = new JLabel("");
		lblImg.setBounds(733, 10, 85, 70);
        ImageIcon icon3 = new ImageIcon("C:\\\\Users\\\\Sam Hernandez\\\\Downloads\\\\VentanaInsertar\\\\VentanaInsertar\\\\colegio.png");
        Icon icono3 = new ImageIcon(icon3.getImage().getScaledInstance(lblImg.getWidth(), lblImg.getHeight(), Image.SCALE_DEFAULT));
        lblImg.setText(null);
        lblImg.setIcon( icono3 );
		frame.getContentPane().add(lblImg);
		
		JLabel lblMatOTaller = new JLabel("\u00BFMateria o Taller?");
		lblMatOTaller.setForeground(new Color(102, 153, 255));
		lblMatOTaller.setFont(new Font("Dialog", Font.BOLD, 18));
		lblMatOTaller.setBounds(43, 292, 162, 25);
		frame.getContentPane().add(lblMatOTaller);
		
		JLabel lblMateria = new JLabel("Materia");
		lblMateria.setForeground(Color.ORANGE);
		lblMateria.setFont(new Font("Dialog", Font.BOLD, 18));
		lblMateria.setBounds(166, 352, 79, 25);
		frame.getContentPane().add(lblMateria);
		
		JLabel lblTaller = new JLabel("Taller");
		lblTaller.setForeground(Color.ORANGE);
		lblTaller.setFont(new Font("Dialog", Font.BOLD, 18));
		lblTaller.setBounds(181, 475, 62, 25);
		frame.getContentPane().add(lblTaller);
		
		JLabel lblNvelEducativo_Taller = new JLabel("N\u00EDvel Educativo");
		lblNvelEducativo_Taller.setForeground(new Color(102, 153, 255));
		lblNvelEducativo_Taller.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNvelEducativo_Taller.setBounds(30, 504, 143, 25);
		frame.getContentPane().add(lblNvelEducativo_Taller);
		
		JLabel lblseparador1 = new JLabel("/");
		lblseparador1.setForeground(new Color(102, 153, 255));
		lblseparador1.setFont(new Font("Dialog", Font.BOLD, 18));
		lblseparador1.setBounds(605, 93, 5, 28);
		frame.getContentPane().add(lblseparador1);
		
		JLabel lblseparador2 = new JLabel("/");
		lblseparador2.setForeground(new Color(102, 153, 255));
		lblseparador2.setFont(new Font("Dialog", Font.BOLD, 18));
		lblseparador2.setBounds(664, 93, 5, 28);
		frame.getContentPane().add(lblseparador2);
		
		JButton btnCancelar = new JButton("");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtNombre.setText(" ");
				txtApellidoP.setText(" ");
				txtApellidoM.setText(" ");
				txtDia.setText(" ");
				textMes.setText(" ");
				textAno.setText(" ");
				txtEdad.setText(" ");
				txtCurp.setText(" ");
				txtNumTel.setText(" ");
				txtDireccion.setText(" ");
				txtCorreoI.setText(" ");
				txtNombreC.setText(" ");
				txtDireccionC.setText(" ");
				txtNumC1.setText(" ");
				txtNumC2.setText(" ");
			}
		});
		btnCancelar.setBackground(Color.WHITE);
		btnCancelar.setBorder(null);
		btnCancelar.setFont(new Font("Apple Garamond", Font.BOLD, 20));
		btnCancelar.setBounds(533, 503, 62, 61);
        ImageIcon icon = new ImageIcon("C:\\Users\\Sam Hernandez\\Downloads\\VentanaInsertar\\VentanaInsertar\\cancelar.png");
        Icon icono = new ImageIcon(icon.getImage().getScaledInstance(btnCancelar.getWidth(), btnCancelar.getHeight(), Image.SCALE_DEFAULT));
        btnCancelar.setText(null);
        btnCancelar.setIcon(icono);	
		frame.getContentPane().add(btnCancelar);
		
		comboArea_Taller.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				rellenaCombo4((String) comboArea_Taller.getSelectedItem());
			}
		});
		
		comboArea.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			rellenaCombo2((String) comboArea.getSelectedItem());
			rellenaCombo3((String) comboArea.getSelectedItem());
		}

	    });

	rellenaCombo2((String) comboArea.getSelectedItem());
	rellenaCombo3((String) comboArea.getSelectedItem());
	rellenaCombo4((String) comboArea_Taller.getSelectedItem());
	
	}
	private void rellenaCombo2(String seleccionEnCombo1) {
		comboMateria.removeAllItems();
		if (seleccionEnCombo1.equals("Maternal")) {
			comboMateria.setModel(new DefaultComboBoxModel(new String[] {"Artes", "Danza", "Desarrollo Humano", "Estimulacion Temprana"}));
			
		} else if (seleccionEnCombo1.equals("Preescolar")) {
			comboMateria.setModel(new DefaultComboBoxModel(new String[] {"Artes", "Computacion", "Danza", "Educacion Fisica", "Desarollo Humano", "Musica", "Robotica"}));

		}else if(seleccionEnCombo1.equals("Primaria")){
			comboMateria.setModel(new DefaultComboBoxModel(new String[] {"Artes", "Computacion", "Danza", "Educacion Fisica", "Desarollo Humano", "Musica", "Robotica"}));
		
		}else if(seleccionEnCombo1.equals("Secundaria")) {
			comboMateria.setModel(new DefaultComboBoxModel(new String[] {"Ingles", "Frances", "Biologia", "Educacion Fisica", "Historia del Arte", "Fisica y Quimica", "Robotica", "Informatica"}));
		}

	}
	private void rellenaCombo3(String seleccionEnCombo1) {
		estadoGradoE.removeAllItems();
		if (seleccionEnCombo1.equals("Maternal")) {
			estadoGradoE.setModel(new DefaultComboBoxModel(new String[] {"Maternal I", "Maternal II", "Maternal III"}));
			
		} else if (seleccionEnCombo1.equals("Preescolar")) {
			estadoGradoE.setModel(new DefaultComboBoxModel(new String[] {"1\u00B0", "2\u00B0", "3\u00B0"}));

		}else if (seleccionEnCombo1.equals("Primaria")) {
			estadoGradoE.setModel(new DefaultComboBoxModel(new String[] {"1\u00B0", "2\u00B0", "3\u00B0", "4\u00B0", "5\u00B0", "6\u00B0" }));
		
		}else if (seleccionEnCombo1.equals("Secundaria")) {
			estadoGradoE.setModel(new DefaultComboBoxModel(new String[] {"1\u00B0", "2\u00B0", "3\u00B0"}));
		}
	
	}
	private void rellenaCombo4(String seleccionEnCombo2) {
		comboTaller.removeAllItems();
		if (seleccionEnCombo2.equals("Maternal")) {
			comboTaller.setModel(new DefaultComboBoxModel(new String[] {"Musica"}));
			
		} else if (seleccionEnCombo2.equals("Preescolar")) {
			comboTaller.setModel(new DefaultComboBoxModel(new String[] {"Lectura"}));

		}else if(seleccionEnCombo2.equals("Primaria")){
			comboTaller.setModel(new DefaultComboBoxModel(new String[] {"Lectura"}));
		}
	}
	class OyenteBtnMateria implements ActionListener{
	    public void actionPerformed(ActionEvent e){
	    	comboArea_Taller.setVisible(false);
			comboTaller.setVisible(false);
			comboArea.setVisible(true);
			comboMateria.setVisible(true);
			estadoGradoE.setVisible(true);
	    }
	}
	class OyenteBtnTaller implements ActionListener{
	    public void actionPerformed(ActionEvent e){
	    	comboArea.setVisible(false);
			comboMateria.setVisible(false);
			estadoGradoE.setVisible(false);
			comboArea_Taller.setVisible(true);
			comboTaller.setVisible(true);
	    }
	}
}